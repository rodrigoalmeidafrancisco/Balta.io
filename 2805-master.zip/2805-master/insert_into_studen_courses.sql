INSERT INTO 
    [Student]
VALUES (
    'c55390d4-71dd-4f3c-b978-d1582f51a327',
    'André Baltieri',
    'hello@balta.io',
    '12345678901',
    '11999999999',
    NULL,
    GETDATE()
)

INSERT INTO 
    [StudentCourse]
VALUES (
    '5d8cf396-e717-9a02-2443-021b00000000',
    'c55390d4-71dd-4f3c-b978-d1582f51a327',
    50,
    0,
    '2021-01-15 12:35:54',
    GETDATE()
)