﻿namespace DependencyInjectionLifetimeSample.Services;

public class PrimaryService
{
    public Guid Id { get; set; } = Guid.NewGuid();
}