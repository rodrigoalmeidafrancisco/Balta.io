﻿namespace DependencyStore.Models;

public class Product
{
    public decimal Price { get; set; }
}