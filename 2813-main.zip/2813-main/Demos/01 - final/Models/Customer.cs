﻿namespace DependencyStore.Models;

public class Customer
{
    
}